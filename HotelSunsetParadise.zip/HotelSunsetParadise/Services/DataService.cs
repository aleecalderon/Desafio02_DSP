using HotelSunsetParadise.Models;

namespace HotelSunsetParadise.Services
{
    public static class DataService
    {
        private static List<Habitacion> _habitaciones = new();
        private static List<Cliente> _clientes = new();
        private static List<Reserva> _reservas = new();
        private static int _nextClienteId = 1;
        private static int _nextReservaId = 1;

        static DataService()
        {
            InicializarDatos();
        }

        private static void InicializarDatos()
        {
            // Habitaciones predefinidas
            _habitaciones.AddRange(new[]
            {
                new Habitacion { Numero = 101, Tipo = "Individual", Precio = 45.00m, Estado = "Disponible" },
                new Habitacion { Numero = 102, Tipo = "Individual", Precio = 45.00m, Estado = "Disponible" },
                new Habitacion { Numero = 201, Tipo = "Doble", Precio = 75.00m, Estado = "Disponible" },
                new Habitacion { Numero = 202, Tipo = "Doble", Precio = 75.00m, Estado = "Disponible" },
                new Habitacion { Numero = 301, Tipo = "Suite", Precio = 120.00m, Estado = "Disponible" },
                new Habitacion { Numero = 302, Tipo = "Suite", Precio = 120.00m, Estado = "Disponible" },
                new Habitacion { Numero = 401, Tipo = "Presidencial", Precio = 200.00m, Estado = "Disponible" }
            });
        }

        // M�todos para Habitaciones
        public static List<Habitacion> ObtenerHabitaciones()
        {
            return _habitaciones.ToList();
        }

        public static List<Habitacion> ObtenerHabitacionesDisponibles()
        {
            return _habitaciones.Where(h => h.Estado == "Disponible").ToList();
        }

        public static Habitacion? ObtenerHabitacionPorNumero(int numero)
        {
            return _habitaciones.FirstOrDefault(h => h.Numero == numero);
        }

        public static bool AgregarHabitacion(Habitacion habitacion)
        {
            if (_habitaciones.Any(h => h.Numero == habitacion.Numero))
                return false;

            _habitaciones.Add(habitacion);
            return true;
        }

        // M�todos para Clientes
        public static List<Cliente> ObtenerClientes()
        {
            return _clientes.ToList();
        }

        public static Cliente? ObtenerClientePorId(int id)
        {
            return _clientes.FirstOrDefault(c => c.Id == id);
        }

        public static bool AgregarCliente(Cliente cliente)
        {
            if (!string.IsNullOrEmpty(cliente.DUI) && _clientes.Any(c => c.DUI == cliente.DUI))
                return false;

            cliente.Id = _nextClienteId++;
            _clientes.Add(cliente);
            return true;
        }

        // M�todos para Reservas
        public static List<Reserva> ObtenerReservas()
        {
            var reservas = _reservas.ToList();

            foreach (var reserva in reservas)
            {
                reserva.Cliente = ObtenerClientePorId(reserva.ClienteId);
                reserva.Habitacion = ObtenerHabitacionPorNumero(reserva.HabitacionNumero);
            }

            return reservas;
        }

        public static bool AgregarReserva(Reserva reserva)
        {
            // Validar solapamiento de fechas
            if (ValidarSolapamientoFechas(reserva.HabitacionNumero, reserva.FechaEntrada, reserva.FechaSalida))
                return false;

            reserva.Id = _nextReservaId++;

            // Calcular total
            var habitacion = ObtenerHabitacionPorNumero(reserva.HabitacionNumero);
            if (habitacion != null)
            {
                reserva.Total = habitacion.Precio * reserva.NumeroNoches;
            }

            _reservas.Add(reserva);

            // Actualizar estado de habitaci�n
            ActualizarEstadoHabitacion(reserva.HabitacionNumero, "Ocupada");

            return true;
        }

        private static bool ValidarSolapamientoFechas(int numeroHabitacion, DateTime fechaEntrada, DateTime fechaSalida)
        {
            return _reservas.Any(r =>
                r.HabitacionNumero == numeroHabitacion &&
                ((fechaEntrada >= r.FechaEntrada && fechaEntrada < r.FechaSalida) ||
                 (fechaSalida > r.FechaEntrada && fechaSalida <= r.FechaSalida) ||
                 (fechaEntrada <= r.FechaEntrada && fechaSalida >= r.FechaSalida))
            );
        }

        private static void ActualizarEstadoHabitacion(int numero, string estado)
        {
            var habitacion = _habitaciones.FirstOrDefault(h => h.Numero == numero);
            if (habitacion != null)
            {
                habitacion.Estado = estado;
            }
        }

        // M�todo para validar login
        public static bool ValidarLogin(string usuario, string contrase�a)
        {
            return usuario == "admin" && contrase�a == "123";
        }
    }
}