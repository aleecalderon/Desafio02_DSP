using System.ComponentModel.DataAnnotations;

namespace HotelSunsetParadise.Models
{
    // Modelo para Habitaciones
    public class Habitacion
    {
        [Required(ErrorMessage = "El n�mero de habitaci�n es requerido")]
        [Display(Name = "N�mero de Habitaci�n")]
        public int Numero { get; set; }

        [Required(ErrorMessage = "El tipo de habitaci�n es requerido")]
        [Display(Name = "Tipo de Habitaci�n")]
        public string Tipo { get; set; } = string.Empty;

        [Required(ErrorMessage = "El precio es requerido")]
        [Range(0.01, double.MaxValue, ErrorMessage = "El precio debe ser mayor a 0")]
        [Display(Name = "Precio por Noche")]
        [DataType(DataType.Currency)]
        public decimal Precio { get; set; }

        [Required(ErrorMessage = "El estado es requerido")]
        [Display(Name = "Estado")]
        public string Estado { get; set; } = "Disponible";
    }

    // Modelo para Clientes
    public class Cliente
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre es requerido")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre Completo")]
        public string Nombre { get; set; } = string.Empty;

        [Required(ErrorMessage = "El DUI es requerido")]
        [Display(Name = "DUI")]
        public string DUI { get; set; } = string.Empty;

        [Required(ErrorMessage = "El tel�fono es requerido")]
        [Display(Name = "Tel�fono")]
        public string Telefono { get; set; } = string.Empty;
    }

    // Modelo para Reservas
    public class Reserva
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Debe seleccionar un cliente")]
        [Display(Name = "Cliente")]
        public int ClienteId { get; set; }

        [Required(ErrorMessage = "Debe seleccionar una habitaci�n")]
        [Display(Name = "Habitaci�n")]
        public int HabitacionNumero { get; set; }

        [Required(ErrorMessage = "La fecha de entrada es requerida")]
        [Display(Name = "Fecha de Entrada")]
        [DataType(DataType.Date)]
        public DateTime FechaEntrada { get; set; }

        [Required(ErrorMessage = "La fecha de salida es requerida")]
        [Display(Name = "Fecha de Salida")]
        [DataType(DataType.Date)]
        public DateTime FechaSalida { get; set; }

        [Display(Name = "Total a Pagar")]
        [DataType(DataType.Currency)]
        public decimal Total { get; set; }

        [Display(Name = "N�mero de Noches")]
        public int NumeroNoches => (FechaSalida - FechaEntrada).Days;

        // Propiedades de navegaci�n
        public Cliente? Cliente { get; set; }
        public Habitacion? Habitacion { get; set; }
    }

    // Modelo para Login
    public class LoginViewModel
    {
        [Required(ErrorMessage = "El usuario es requerido")]
        [Display(Name = "Usuario")]
        public string Usuario { get; set; } = string.Empty;

        [Required(ErrorMessage = "La contrase�a es requerida")]
        [Display(Name = "Contrase�a")]
        [DataType(DataType.Password)]
        public string Contrase�a { get; set; } = string.Empty;
    }
}