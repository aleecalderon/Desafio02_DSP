
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using HotelSunsetParadise.Models;
using HotelSunsetParadise.Services;

namespace HotelSunsetParadise.Controllers
{
    public class ReservasController : BaseController
    {
        public IActionResult Index()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Account");

            var reservas = DataService.ObtenerReservas();
            return View(reservas);
        }

        [HttpGet]
        public IActionResult Crear()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Account");

            CargarDropdowns();
            return View();
        }

        [HttpPost]
        public IActionResult Crear(Reserva reserva)
        {
            if (ModelState.IsValid)
            {
                if (reserva.FechaEntrada >= reserva.FechaSalida)
                {
                    ModelState.AddModelError("FechaSalida", "La fecha de salida debe ser posterior a la fecha de entrada");
                }
                else if (reserva.FechaEntrada < DateTime.Today)
                {
                    ModelState.AddModelError("FechaEntrada", "La fecha de entrada no puede ser anterior a hoy");
                }
                else
                {
                    if (DataService.AgregarReserva(reserva))
                    {
                        TempData["Mensaje"] = "Reserva creada exitosamente";
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ModelState.AddModelError("", "La habitaci�n no est� disponible en las fechas seleccionadas");
                    }
                }
            }

            CargarDropdowns();
            return View(reserva);
        }

        private void CargarDropdowns()
        {
            var clientes = DataService.ObtenerClientes();
            var habitacionesDisponibles = DataService.ObtenerHabitacionesDisponibles();

            ViewBag.ClienteId = new SelectList(clientes, "Id", "Nombre");
            ViewBag.HabitacionNumero = new SelectList(habitacionesDisponibles, "Numero", "Numero");
        }
    }
}