using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using HotelSunsetParadise.Models;
using HotelSunsetParadise.Services;

namespace HotelSunsetParadise.Controllers
{
    public class HomeController : BaseController
    {
        public IActionResult Index()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Account");

            ViewBag.TotalHabitaciones = DataService.ObtenerHabitaciones().Count;
            ViewBag.HabitacionesDisponibles = DataService.ObtenerHabitacionesDisponibles().Count;
            ViewBag.TotalClientes = DataService.ObtenerClientes().Count;
            ViewBag.ReservasActivas = DataService.ObtenerReservas().Count;

            return View();
        }
    }
}