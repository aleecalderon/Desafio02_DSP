using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using HotelSunsetParadise.Models;
using HotelSunsetParadise.Services;

namespace HotelSunsetParadise.Controllers
{
    public class HabitacionesController : BaseController
    {
        public IActionResult Index()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Account");

            var habitaciones = DataService.ObtenerHabitaciones();
            return View(habitaciones);
        }

        [HttpGet]
        public IActionResult Crear()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Account");

            return View();
        }

        [HttpPost]
        public IActionResult Crear(Habitacion habitacion)
        {
            if (ModelState.IsValid)
            {
                if (DataService.AgregarHabitacion(habitacion))
                {
                    TempData["Mensaje"] = "Habitaci�n agregada exitosamente";
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("Numero", "Ya existe una habitaci�n con este n�mero");
                }
            }
            return View(habitacion);
        }

        public IActionResult Disponibles()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Account");

            var habitacionesDisponibles = DataService.ObtenerHabitacionesDisponibles();
            return View(habitacionesDisponibles);
        }
    }
}