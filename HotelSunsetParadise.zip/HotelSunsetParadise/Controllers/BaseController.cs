using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace HotelSunsetParadise.Controllers
{
    public class BaseController : Controller
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            ViewBag.IsAuthenticated = IsAuthenticated();
            if (IsAuthenticated())
            {
                ViewBag.Usuario = HttpContext.Session.GetString("Usuario");
            }

            base.OnActionExecuting(context);
        }

        protected bool IsAuthenticated()
        {
            return HttpContext.Session.GetString("IsAuthenticated") == "true";
        }

        protected void SetAuthenticatedUser(string usuario)
        {
            HttpContext.Session.SetString("IsAuthenticated", "true");
            HttpContext.Session.SetString("Usuario", usuario);
        }

        protected void ClearAuthentication()
        {
            HttpContext.Session.Clear();
        }
    }
}