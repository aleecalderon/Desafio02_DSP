
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using HotelSunsetParadise.Models;
using HotelSunsetParadise.Services;

namespace HotelSunsetParadise.Controllers
{
    public class AccountController : BaseController
    {
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (DataService.ValidarLogin(model.Usuario, model.Contrase�a))
                {
                    SetAuthenticatedUser(model.Usuario);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "Usuario o contrase�a incorrectos");
                }
            }
            return View(model);
        }

        public IActionResult Logout()
        {
            ClearAuthentication();
            return RedirectToAction("Login");
        }
    }
}