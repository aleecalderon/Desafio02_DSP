using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using HotelSunsetParadise.Models;
using HotelSunsetParadise.Services;

namespace HotelSunsetParadise.Controllers
{
    public class ClientesController : BaseController
    {
        public IActionResult Index()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Account");

            var clientes = DataService.ObtenerClientes();
            return View(clientes);
        }

        [HttpGet]
        public IActionResult Crear()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Account");

            return View();
        }

        [HttpPost]
        public IActionResult Crear(Cliente cliente)
        {
            if (ModelState.IsValid)
            {
                if (DataService.AgregarCliente(cliente))
                {
                    TempData["Mensaje"] = "Cliente registrado exitosamente";
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("DUI", "Ya existe un cliente con este DUI");
                }
            }
            return View(cliente);
        }
    }
}
